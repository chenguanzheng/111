$(function(){
	var pid=GetQueryString("pid"); 
		
})