$(function(){
	 $("#big_box").load("toubu.html","",function(){
  	
  })
$("#foot").load("公用尾部.html","",function(){
  	
  })
})